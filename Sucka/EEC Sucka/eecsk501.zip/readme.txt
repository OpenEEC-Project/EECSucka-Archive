EECSK500.ZIP - Distribution file list

readme.txt     Distribution file list
eecsk501.pdf   Circuit diagram v5.01

eecsucka.exe   DOS executable v5.00
eecsucka.c     Source code module
eecsucka.h     Source code module
io.c           Source code module
io.h           Source code module
test.c         Source code module
test.h         Source code module

PDF files require Adobe Acrobat viewer
