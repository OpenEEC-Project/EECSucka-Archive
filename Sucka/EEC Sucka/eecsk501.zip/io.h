/*-----------------------------------------------------------------------
 * File:
 *      io.h
 * Purpose:
 *      I/O header file for EEC-IV/V ROM dumper
 * Author:
 *      Andrew March - amarch@icenet.com.au
 * Notes:
 *---------------------------------------------------------------------*/

/*-----------------------------------------------------------------------
 * Includes
 *---------------------------------------------------------------------*/

/*-----------------------------------------------------------------------
 * Global constants
 *---------------------------------------------------------------------*/

// printer register inversions
#define DATA_IN_INVERSIONS      0x80
#define CONTROL_INVERSIONS      0x0b

// printer port data outputs standard naming
#define PIN_2_D0                0x01
#define PIN_3_D1                0x02
#define PIN_4_D2                0x04
#define PIN_5_D3                0x08
#define PIN_6_D4                0x10
#define PIN_7_D5                0x20
#define PIN_8_D6                0x40
#define PIN_9_D7                0x80

// printer port data outputs eecsucka notation
#define PD0                     PIN_2_D0
#define PD1                     PIN_3_D1
#define PD2                     PIN_4_D2
#define PD3                     PIN_5_D3
#define PD4                     PIN_6_D4
#define PD5                     PIN_7_D5
#define PD6                     PIN_8_D6
#define PD7                     PIN_9_D7

// printer port control outputs standard naming
#define PIN_1_STROBE            0x01
#define PIN_14_AUTO_FEED		0x02
#define PIN_16_INIT             0x04
#define PIN_17_SELECT_INPUT     0x08

// latch outputs
#define Q0                      0x80
#define Q1                      0x20
#define Q2                      0x08
#define Q3                      0x02
#define Q4                      0x01
#define Q5                      0x04
#define Q6                      0x10
#define Q7                      0x40

// eec control signals
#define SPARE1                  Q0
#define MRESET                  Q1
#define IT                      Q2
#define BS0                     Q3
#define BS3                     Q4
#define DI                      Q5
#define ST                      Q6
#define MB5                     Q7

// eecsucka control signals

// PIN_9_D7=0 selects low nibble
// PIN_9_D7=1 selects high nibble
#define SELECT_HIGH_NIBBLE      PIN_9_D7

// PIN_1_STROBE=0->1->0 latches data present at latch inputs
#define LATCH_ENABLE            PIN_1_STROBE


/*-----------------------------------------------------------------------
 * Global variables
 *---------------------------------------------------------------------*/
#ifndef _IO_C
extern unsigned char latch_shadow;      // interface latch shadow
extern unsigned char data_shadow;       // data output register shadow
extern unsigned char control_shadow;    // control output register shadow

#endif /* _IO_C */

/*-----------------------------------------------------------------------
 * Global function prototypes
 *---------------------------------------------------------------------*/
unsigned char get_mbus_data(void);
void initialise_hardware(void);


/*-----------------------------------------------------------------------
 * Global inlining
 *---------------------------------------------------------------------*/
/*-----------------------------------------------------------------------
 * write a data byte to the parallel port data output register
 *---------------------------------------------------------------------*/
#define output_port_data(data_value)                                    \
{                                                                       \
	data_shadow = data_value;                                           \
	outportb(lpt_data_port, data_shadow);                               \
}


/*-----------------------------------------------------------------------
 * write a control byte to the parallel port control output register
 * top nibble is cleared to keep data lines as outputs in case of ECP/EPP
 * the control byte is copied to a shadow variable to allow bit set/clear
 * note that any inversions due to PC or application hardware are defined
 * by CONTROL_INVERSIONS and they are handled here
 *---------------------------------------------------------------------*/
#define output_port_control(control_value)                              \
{                                                                       \
	control_shadow = (control_value) & 0x0f;                            \
	outportb(lpt_control_port, control_shadow^CONTROL_INVERSIONS);      \
}


/*-----------------------------------------------------------------------
 * write a data byte to the interface latch
 * present data to latch inputs then pulse the latch enable input high
 *---------------------------------------------------------------------*/
#define output_latch_data(latch_value)                                  \
{                                                                       \
	latch_shadow = latch_value;                                         \
	output_port_data(latch_shadow);                                     \
	output_port_data(latch_shadow);                                     \
	output_port_data(latch_shadow);                                     \
	output_port_data(latch_shadow);                                     \
	output_port_data(latch_shadow);                                     \
	output_port_data(latch_shadow);                                     \
	output_port_data(latch_shadow);                                     \
	output_port_control(control_shadow|LATCH_ENABLE);                   \
	output_port_control(control_shadow|LATCH_ENABLE);                   \
	output_port_control(control_shadow|LATCH_ENABLE);                   \
	output_port_control(control_shadow|LATCH_ENABLE);                   \
	output_port_control(control_shadow|LATCH_ENABLE);                   \
	output_port_control(control_shadow|LATCH_ENABLE);                   \
	output_port_control(control_shadow|LATCH_ENABLE);                   \
	output_port_control(control_shadow|LATCH_ENABLE);                   \
	output_port_control(control_shadow|LATCH_ENABLE);                   \
	output_port_control(control_shadow|LATCH_ENABLE);                   \
	output_port_control(control_shadow&~LATCH_ENABLE);                  \
}


/*-----------------------------------------------------------------------
 * bring latch Qx line low
 *---------------------------------------------------------------------*/
#define clear_latch_bit(Qx)                                                      \
{                                                                       \
	output_latch_data(latch_shadow&~Qx);                                \
}


/*-----------------------------------------------------------------------
 * bring latch Qx line high
 *---------------------------------------------------------------------*/
#define set_latch_bit(Qx)                                                        \
{                                                                       \
	output_latch_data(latch_shadow|Qx);                                 \
}


/*-----------------------------------------------------------------------
 * pulse TSTSTB to increment EEC ROM address counter
 *---------------------------------------------------------------------*/
#define strobe_ST()                                                     \
{                                                                       \
	clear_latch_bit(ST);                                                \
	clear_latch_bit(ST);                                                \
	set_latch_bit(ST);                                                  \
	set_latch_bit(ST);                                                  \
}


/*-----------------------------------------------------------------------
 * write data to select low nibble of input data
 *---------------------------------------------------------------------*/
#define select_low_nibble()                                             \
{                                                                       \
	output_port_data(0x00);                          					\
}


/*-----------------------------------------------------------------------
 * write data to select high nibble of input data
 *---------------------------------------------------------------------*/
#define select_high_nibble()                                            \
{                                                                       \
	output_port_data(SELECT_HIGH_NIBBLE);            					\
}


/*-----------------------------------------------------------------------
 * interrupt control
 *---------------------------------------------------------------------*/
#define enable_interrupts()     enable()
#define disable_interrupts()    disable()

/*-----------------------------------------------------------------------
 * End of file
 *---------------------------------------------------------------------*/
