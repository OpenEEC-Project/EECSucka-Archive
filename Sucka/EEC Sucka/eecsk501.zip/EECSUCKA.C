/*-----------------------------------------------------------------------
 * File:
 * 		eecsucka.c
 * Purpose:
 * 		Control software for EEC-IV/V ROM dumper
 * Author:
 * 		Andrew March - amarch@icenet.com.au
 * Revisions:
 * 		 1 Apr 2000 - v5.00 EEC-V ROM dump over MBUS.
 * Notes:
 *---------------------------------------------------------------------*/
#ifndef _EECSUCKA_C
#define _EECSUCKA_C
#endif

/*-----------------------------------------------------------------------
 * Includes
 *---------------------------------------------------------------------*/
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dos.h>
#include <time.h>
#include "eecsucka.h"
#include "io.h"
#include "test.h"


/*-----------------------------------------------------------------------
 * Global variables
 *---------------------------------------------------------------------*/
unsigned int lpt_data_port   = 0x378;
unsigned int lpt_status_port = 0x379;
unsigned int lpt_control_port= 0x37a;


/*-----------------------------------------------------------------------
 * Local constants
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local variables
 *---------------------------------------------------------------------*/

/* set up defaults for parsing of command line options */
unsigned int port_number = 1;
unsigned long num_banks = 4;
unsigned long bank_ofst = 8*1024L;
unsigned long bank_size = 56*1024L;
unsigned long rom_size = 56*1024L;
char file_name[20] = "dump.bin";
int dump_required = TRUE;
int using_menu = TRUE;
int show_usage = FALSE;


/*-----------------------------------------------------------------------
 * Local function prototypes
 *---------------------------------------------------------------------*/
int parse_command_line(int argc, char *argv[]);
int init_printer_port(void);
void display_usage(void);
int menu_mode(void);
int batch_mode(void);
void display_main_menu(void);
void get_file_name(void);

void initialise_EEC(void);
void select_bank(int bank_number);
int verify_ROM(void);
int dump_ROM(void);
int show_ROM(void);
void display_hex_data (unsigned char * array, unsigned long len, unsigned long offset);


/*-----------------------------------------------------------------------
 * Main program
 *---------------------------------------------------------------------*/
main(int argc, char *argv[])
{
	int result;


	if ( parse_command_line(argc, &argv[0]) != 0 )
	{
		exit(1);
	}

	if ( init_printer_port() != 0 )
	{
		exit(1);
	}
	else
	{
		// if printer port found we can init pc and interface hardware
		initialise_hardware();
	}

	if (show_usage == TRUE)
	{
		display_usage();
		exit(0);
	}
	else if (using_menu == TRUE)
	{
		menu_mode();
		exit(0);
	}
	else
	{
		result = batch_mode();
		exit(result);
	}

	return(0); // suppresses warning
}


/*-----------------------------------------------------------------------
 * Extract command line options
 * Print error messages to stderr
 * Change defaults according to the command line options
 *---------------------------------------------------------------------*/
int parse_command_line(int argc, char *argv[])
{
	int i;
	int kilobytes;
	int port;
	int result;


	i = 0;
	result = 0;

	while ( (++i < argc) && (result == 0) )
	{
		if ( (*argv[i] == '-') || (*argv[i] == '/') )
		{
			switch (argv[i][1])
			{
				case 'b':
				case 'B':
					using_menu = FALSE;
					break;

				case 'f':
				case 'F':
					strcpy(file_name, argv[++i]);
					break;

				case 'v':
				case 'V':
					// verify only?
					dump_required = FALSE;
					break;

				case 'p':
				case 'P':
					if ( sscanf(argv[++i], "%d", &port) != 1 )
					{
						fprintf(stderr,"EECSucka: Bad number format for -p option\n");
						result = 1;
					}
					else if ( (port < 1) || (port > 4) )
					{
						fprintf(stderr,"EECSucka: Bad number range for -p option\n");
						result = 1;
					}
					else
					{
						port_number = port;
					}
					break;

				case 'h':
				case 'H':
					show_usage = TRUE;
					break;

				default:
					fprintf(stderr,"EECSucka: Unknown option -%c\n", argv[i][1]);
					result = 1;
					break;
			}
		}
		else
		{
			fprintf(stderr,"EECSucka: Unexpected character %c\n", *argv[i]);
			result = 1;
		}
	}

	return(result);
}


/*-----------------------------------------------------------------------
 * Print usage guide to screen
 *---------------------------------------------------------------------*/
void display_usage(void)
{
	clrscr();
	printf("\n");
	printf("          EECSucka v5.00 EEC-V ROM dumper (C) Andrew J March 2000 \n");
	printf("          ------------------------------------------------------- \n");
	printf("Help screen:  eecsucka -h\n");
	printf("Menu mode:    eecsucka [-f file.ext] [-p 1..4]\n");
	printf("Command line: eecsucka -b [-f file.ext] [-v] [-p 1..4]\n");
	printf("\n");
	printf("  -h   Display these usage notes\n");
	printf("\n");
	printf("  -b   Batch mode\n");
	printf("         Default = menu mode\n");
	printf("\n");
	printf("  -f   File name to dump/verify ROM (8.3 format)\n");
	printf("         Default = dump.bin\n");
	printf("\n");
	printf("  -v   Verify ROM without dumping\n");
	printf("         Default = Dump and verify ROM\n");
	printf("\n");
	printf("  -p   Specify parallel port 1, 2, 3 or 4\n");
	printf("         Default = LPT1\n");
}


/*-----------------------------------------------------------------------
 * Perform command line options in batch mode
 *---------------------------------------------------------------------*/
int batch_mode(void)
{
	int result;


	// we're either dumping+verifying or verfying
	if ( dump_required == TRUE)
	{
		dump_ROM();
	}

	// always verify
	if ( verify_ROM() != 0 )
	{
		result = 1;
	}
	else
	{
		result = 0;
	}

	return(result);
}


/*-----------------------------------------------------------------------
 * Check whether a port exists for the requested port number
 * if port exists, set up port addresses
 *
 * BIOS lookup table at 0000:0408 returns port address or 0 if no port
 *---------------------------------------------------------------------*/
int init_printer_port(void)
{
	unsigned int lpt_base;
	int result;


	// lookup port base address for requested port number from the BIOS table
	lpt_base = *((unsigned int far *)(0x00000408L)+(port_number-1));

	if (lpt_base == 0)
	{
		fprintf(stderr, "EECSucka: No port found for LPT%d \n", port_number);
		result = 1;
	}
	else
	{
		fprintf(stderr, "EECSucka: Using LPT%d at %Xh\n", port_number, lpt_base);
		lpt_data_port   = lpt_base;
		lpt_status_port = lpt_base + 1;
		lpt_control_port= lpt_base + 2;
		result = 0;
	}

	return(result);
}


/*-----------------------------------------------------------------------
 * User control via menu
 *---------------------------------------------------------------------*/
int menu_mode(void)
{
	int c;


	initialise_hardware();

	do
	{
		clrscr();
		display_main_menu();
		c = toupper(getch());

		switch (c)
		{
			case 'D':
				// dump ROM contents to binary file
				clrscr();
				get_file_name();
				dump_ROM();
				verify_ROM();
				press_any_key();
				break;

			case 'S':
				// show ROM contents on screen
				clrscr();
				show_ROM();
				break;

			case 'V':
				// verify memory device against binary file
				clrscr();
				get_file_name();
				verify_ROM();
				press_any_key();
				break;

			case 'T':
				// test menu
				clrscr();
				select_test();
				break;

			case 'Q':
				// Quit
				break;

			default:
				printf("Invalid option!");
				press_any_key();
				break;
		}
	}
	while (c!='Q');

	clrscr();

	return(0);
}


/*-----------------------------------------------------------------------
 * wait for user to press a key
 *---------------------------------------------------------------------*/
int press_any_key( void)
{
	printf("\nPress any key to continue... ");
	return(getch());
}


/*-----------------------------------------------------------------------
 * Local functions
 *---------------------------------------------------------------------*/

/*-----------------------------------------------------------------------
 * Display main menu
 *---------------------------------------------------------------------*/
void display_main_menu( void)
{
	clrscr();
	printf("\n\n\n");
	printf("                         EECSucka v5.00 Main Menu                   \n");
	printf("                         ------------------------                   \n");
	printf("\n");
	printf("                      D. Dump EEC ROM to binary file\n");
	printf("                      S. Show EEC ROM on screen\n");
	printf("                      V. Verify EEC ROM against binary file\n");
	printf("                      T. Test menu                                 \n");
	printf("                      Q. Quit                                      \n");
	printf("\n");
	printf("                         Select: \n\n\n");
}


/*-----------------------------------------------------------------------
 * prompt user to enter file name
 *---------------------------------------------------------------------*/
void get_file_name(void)
{
	char input_line[100];
	char new_file_name[100];
	int i;

	printf("Enter filename [%s]: ", file_name);

	// overwrite default file name with non-empty input line
	gets(input_line);
	if (sscanf(input_line, "%s", new_file_name)==1)
	{
		strcpy(file_name, new_file_name);
	}
}

/*-----------------------------------------------------------------------
 * initialise EEC for ROM dumping
 *---------------------------------------------------------------------*/
void initialise_EEC(void)
{
	set_latch_bit(ST);
	set_latch_bit(DI);
	set_latch_bit(IT);
	set_latch_bit(MRESET);
	set_latch_bit(MB5);
	set_latch_bit(BS0);
	set_latch_bit(BS3);
	delay(100);
}

/*-----------------------------------------------------------------------
 * select nominated bank and init ROM SPC to address 0x2000
 *---------------------------------------------------------------------*/
void select_bank(int bank_number)
{
	// set/clear BS0 and BS3 as required to select nominated bank
	switch (bank_number)
	{
		case 0:
			clear_latch_bit(BS0);
			set_latch_bit(BS3);
			break;
		case 1:
			set_latch_bit(BS0);
			clear_latch_bit(BS3);
			break;
		case 2:
			clear_latch_bit(BS0);
			clear_latch_bit(BS3);
			break;
		case 3:
			set_latch_bit(BS0);
			set_latch_bit(BS3);
			break;
	}

	// initialise SPC to address 0x2000 in the nominated bank
	clear_latch_bit(MRESET);
	clear_latch_bit(DI);
	clear_latch_bit(MB5);
	strobe_ST();
	clear_latch_bit(MB5);
	strobe_ST();
	set_latch_bit(MB5);
	strobe_ST();
	set_latch_bit(DI);
	set_latch_bit(MRESET);
	delay(1);

	// pull down MB5 just like other data lines
	clear_latch_bit(MB5);
//	set_latch_bit(MB5);
}

/*-----------------------------------------------------------------------
 * dump ROM contents to binary file
 *---------------------------------------------------------------------*/
int dump_ROM(void)
{
	FILE *disk_file;
	int bank;
	unsigned long byte_count;
	unsigned long address;
	unsigned char data;
	int progress_count;


	if ((disk_file = fopen(file_name, "wb")) == NULL)
	{
		printf("Unable to open file %s - check disk\n", file_name);
		return(1);
	}

	initialise_EEC();

	byte_count = 0;
	progress_count = 0;

	for (bank = 0; bank < num_banks; bank++)
	{
		select_bank(bank);

		for (address = bank_ofst; address<bank_ofst+bank_size; address++)
		{
			// display progress every 0x100 bytes
			if (progress_count==0x0100)
			{
				printf("\rSaving bank %1d location 0x%05lX...", bank, address);
				progress_count = 0;
			}

			// save ROM data at current address to file
			data = get_mbus_data();
			fputc(data, disk_file);
			byte_count++;
			progress_count++;

			// increment the ROM's internal address counter
			strobe_ST();
		}
	}

	fclose(disk_file);
	printf("\rSaving bank %1d location 0x%05lX... %6ld bytes OK!\n", bank-1, address-1, byte_count);
	return(0);
}


/*-----------------------------------------------------------------------
 * verify ROM contents against binary file
 *---------------------------------------------------------------------*/
int verify_ROM(void)
{
	FILE *disk_file;
	int bank;
	unsigned long byte_count;
	unsigned long address;
	unsigned char rom_data;
	int file_data;
	int mismatch;
	int progress_count;
	int result;


	if ((disk_file = fopen(file_name, "rb")) == NULL)
	{
		if (using_menu == TRUE)
		{
			printf("Unable to open file %s - check disk\n", file_name);
			return(1);
		}
		else
		{
			fprintf(stderr, "EECSucka: Unable to open file %s - check disk\n", file_name);
			return(1);
		}
	}

	// get first byte
	if ((file_data = fgetc(disk_file))==EOF)
	{
		printf("Empty file!!!\n");
		fclose(disk_file);
		return(1);
	}

	initialise_EEC();
	bank = 0;
	select_bank(bank);

	address = bank_ofst;
	byte_count = 0;
	progress_count = 0;
	mismatch = FALSE;

	while( (file_data!=EOF) && (bank<num_banks) && (mismatch==FALSE) )
	{
		// display progress every 0x100 bytes
		if (progress_count==0x100)
		{
			printf("\rVerifying bank %1d location 0x%05lX...", bank, address);
			progress_count = 0;
		}

		rom_data = get_mbus_data();

		if (rom_data!=file_data)
		{
			mismatch = TRUE;
		}
		else // set up next comparison
		{
			byte_count++;

			if (++address >= bank_ofst+bank_size)
			{
				if (++bank < num_banks)
				{
					select_bank(bank);
					address = bank_ofst;
					file_data = fgetc(disk_file);
					progress_count++;
				}
			}
			else
			{
				// increment ROM internal address counter
				strobe_ST();
				file_data = fgetc(disk_file);
				progress_count++;
			}
		}
	}

	if (mismatch==TRUE)
	{
		printf("\rVerifying bank %1d location 0x%05lX... failed!!! Expected 0x%02X, read 0x%02X.\n", bank, address, file_data, rom_data);

		if (using_menu == FALSE)
		{
			fprintf(stderr, "EECSucka: Bad verify at bank %1d location 0x%05lX. Expected 0x%02X, read 0x%02X.\n", bank, address, file_data, rom_data);
		}

		result = 1;
	}
	else
	{
		printf("\rVerifying bank %1d location 0x%05lX... %6ld bytes OK!\n", bank-1, address-1, byte_count);
		result = 0;
	}

	fclose( disk_file);

	return(result);
}


/*-----------------------------------------------------------------------
 * show ROM contents on the screen (first bank only)
 *---------------------------------------------------------------------*/
int show_ROM(void)
{
	unsigned long address;
	unsigned char data[0x800];
	int block_size;
	int byte_count;
	int quit;


	initialise_EEC();
	select_bank(0);

	address = bank_ofst;
	block_size = 0x100;
	quit = FALSE;

	do
	{
		byte_count = 0;

		while ( (byte_count<block_size) && (address<bank_ofst+bank_size) )
		{
			data[byte_count++] = get_mbus_data();
			strobe_ST(); // increment ROM address counter
			address++;
		}

		clrscr();
		display_hex_data(&data[0], byte_count, address-block_size);
		printf("\nPress Q to quit or any other key to continue");

		if ( toupper(getch())=='Q' )
		{
			quit = TRUE;
		}

	} while (!quit);

	return(0);
}


/*-----------------------------------------------------------------------
 * Display memory array in format:
 * addr data (hexadecimal)								  data (ascii)
 * 027F: 30 31 32 33 34 35 36 37 30 31 32 33 34 35 36 37  0123456701234567
 *---------------------------------------------------------------------*/
void display_hex_data
	(
	unsigned char * array,				// pointer to bytes to display
	unsigned long len,      			// number of bytes to display
	unsigned long offset    			// displayed address of first byte
	)

{
	int item;							// index into array
	int cnt;                			// number of bytes so far displayed
	int line_cnt;           			// number of lines displayed in current block
	unsigned char c;


	item = 0;
	while (item<len)
	{
		// display address
		printf("0x%05lX: ", offset+item);

		// display up to 16 data bytes
		cnt = 0;
		while ( (cnt<16) && ((item+cnt) < len) )
		{
			printf("%02X ", array[item+cnt]);
			cnt++;
		}

		// pad with spaces up to start of ASCII column
		while (cnt<16)
		{
			printf("   ");
			cnt++;
		}
		printf(" ");

		// display up to 16 ascii chars. if non-printing code, show '.'
		cnt = 0;
		while ( (cnt<16) && ((item+cnt) < len) )
		{
			c = array[item+cnt];
			if ( (c>=0x20) && (c<=0x7f) )
			{
				printf("%c", c);
			}
			else
			{
				printf(".");
			}
			cnt++;
		}

		item += cnt;				// mark off number of bytes displayed
		printf("\n");               // and start a new line
	}
}


/*-----------------------------------------------------------------------
 * End of file
 *---------------------------------------------------------------------*/


