/*----------------------------------------------------------------------
 * File:
 *		test.c
 * Purpose:
 * 		test functions for EEC-IV/V ROM dumper
 * Author:
 * 		Andrew March - amarch@icenet.com.au
 * Notes:
 ----------------------------------------------------------------------*/
#ifndef _TEST_C
#define _TEST_C
#endif

/*-----------------------------------------------------------------------
 * Includes
 *---------------------------------------------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dos.h>
#include <time.h>
#include "eecsucka.h"
#include "io.h"


/*-----------------------------------------------------------------------
 * Global variables
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local constants
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local variables
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local function prototypes
 *---------------------------------------------------------------------*/
void display_test_menu(void);
void test_parallel_port(void);
void test_mbus_read(void);
void test_latch_out(void);


/*-----------------------------------------------------------------------
 * Global functions
 *---------------------------------------------------------------------*/

/*-----------------------------------------------------------------------
 * Select a test function
 *---------------------------------------------------------------------*/
void select_test(void)
{
	int c;


	do
	{
		initialise_hardware();
		display_test_menu();
		c = toupper(getch());
		switch (c)
			{
		case 'A':
			test_parallel_port();
			break;
		case 'L':
			test_latch_out();
			break;
		case 'M':
			test_mbus_read();
			break;
		case 'Q':
			break;
		default:
			printf("Invalid option!");
			press_any_key();
			break;
			}
	}
	while (c!='Q');
}


/*-----------------------------------------------------------------------
 * Local functions
 *---------------------------------------------------------------------*/

/*-----------------------------------------------------------------------
 * display test menu
 *---------------------------------------------------------------------*/
void display_test_menu( void)
{
	clrscr();
	printf("\n\n\n");
	printf("                         Test Menu                    \n");
	printf("                         ---------                    \n");
	printf("\n");
	printf("                      A. Parallel port                \n");
	printf("                      L. Latch (Q0:7)                 \n");
	printf("                      M. Input data mux (MB0:7)       \n");
	printf("                      Q. Return to main menu          \n");
	printf("\n");
	printf("                         Select: \n\n\n");
}


/*-----------------------------------------------------------------------
 * test operation of parallel port
 * on user key-press set data lines then control lines high one at a time
 * while displaying state of the input lines
 *---------------------------------------------------------------------*/
void test_parallel_port(void)
{
	unsigned char status;
	int	c;
	int index = 0;
	int pattern[] = {
					0x100, 0x001, 0x002, 0x004, // STROBE- DO D1 D2
					0x008, 0x010, 0x020, 0x040, // D3 D4 D5 D6
					0x080, 0x200, 0x400, 0x800  // D7 AUTOF- INIT- SEL.IN-					} ;
					} ;


	initialise_hardware();

	do
	{
		status = inportb(lpt_status_port) ^ DATA_IN_INVERSIONS;
		outportb(lpt_data_port, pattern[index] & 0xff);
		outportb(lpt_control_port, (pattern[index] >> 8) ^ CONTROL_INVERSIONS);

		clrscr();
		printf("    Parallel port test    \n");
		printf("--------------------------\n");
		printf("Outputs are in UPPER CASE \n");
		printf("--------------------------\n");
		printf(" 1  STROBE-    (N/C)  ");
		if (index == 0)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 2  DATA 0     (PD0)  ");
		if ( index == 1)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 3. DATA 1     (PD1)  ");
		if (index == 2)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 4. DATA 2     (PD2)  ");
		if (index == 3)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 5. DATA 3     (PD3)  ");
		if (index == 4)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 6. DATA 4     (PD4)  ");
		if (index == 5)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 7. DATA 5     (PD5)  ");
		if (index == 6)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 8. DATA 6     (PD6)  ");
		if (index == 7)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 9. DATA 7     (PD7)  ");
		if (index == 8)
			printf("1<-\n");
		else
			printf("0\n");

		printf("10. ack-       (PN2)  %d\n", (status & 0x40) ? 1: 0);
		printf("11. busy       (PN3)  %d\n", (status & 0x80) ? 1: 0);
		printf("12. paper end  (PN1)  %d\n", (status & 0x20) ? 1: 0);
		printf("13. select     (PN0)  %d\n", (status & 0x10) ? 1: 0);

		printf("14. AUTO FEED- (N/C)  ");
		if ( index == 9)
			printf("1<-\n");
		else
			printf("0\n");

		printf("15. error-     (N/C)  %d\n", (status & 0x08) ? 1: 0);

		printf("16. INIT-      (PC0)  ");
		if (index == 10)
			printf("1<-\n");
		else
			printf("0\n");

		printf("17. SEL INPUT- (PC1)  ");
		if (index == 11)
			printf("1<-\n");
		else
			printf("0\n");

		printf("--------------------------\n");

		index = (index+1) % 12;

		printf("\nPress any key or Q to quit\n");
		c = toupper(getch());
	}
	while(c!='Q');
	initialise_hardware();
}


/*-----------------------------------------------------------------------
 * test operation of input data multiplexer
 * on user key-press display data byte present on MB[7:0]
 *---------------------------------------------------------------------*/
void test_mbus_read(void)
{
	unsigned char b;
	int	c;


	initialise_hardware();

	do
	{
		clrscr();
		b = get_mbus_data();
		printf("Data input mux test\n");
		printf("-------------------\n");
		printf("Data read = 0x%02X\n", b);
		printf("\nPress any key or Q to quit\n");
		c = toupper(getch());
	}
	while(c!='Q');

	initialise_hardware();
}


/*-----------------------------------------------------------------------
 * bring each latch output high in sequence Q0 to Q7
 *---------------------------------------------------------------------*/
void test_latch_out(void)
{
	unsigned char c;
	int output_bit;

	// write latch_data[1] to set latch output Q0
	// should really be #defined in IO.H
	unsigned char latch_data[8] = {0x80,0x20,0x08,0x02,0x01,0x04,0x10,0x40};


	initialise_hardware();
	output_bit = 0;

	do
	{
		clrscr();
		output_latch_data(latch_data[output_bit]);
		printf("Output latch test\n");
		printf("-----------------\n");
		printf("Q%d is high      \n", output_bit);
		printf("\nPress any key or Q to quit\n");

		output_bit = (output_bit+1) & 0x07;

		c = toupper(getch());
	}
	while(c!='Q');

	initialise_hardware();
}

/*-----------------------------------------------------------------------
 * End of file
 *---------------------------------------------------------------------*/


