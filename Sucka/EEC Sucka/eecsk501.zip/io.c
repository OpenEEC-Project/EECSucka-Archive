/*----------------------------------------------------------------------
 * File:
 *		io.c
 * Author:
 * 		Andrew March - amarch@icenet.com.au
 * Purpose:
 * 		I/O low level routines for EEC-IV/V ROM dumper
 * Notes:
 ----------------------------------------------------------------------*/
#ifndef _IO_C
#define _IO_C
#endif

/*-----------------------------------------------------------------------
 * Includes
 *---------------------------------------------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dos.h>
#include <time.h>
#include "eecsucka.h"
#include "io.h"


/*-----------------------------------------------------------------------
 * Global variables
 *---------------------------------------------------------------------*/
unsigned char latch_shadow;  		  	// interface latch shadow
unsigned char data_shadow;  		  	// data output register shadow
unsigned char control_shadow;  		  	// control output register shadow


/*-----------------------------------------------------------------------
 * Local constants
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local variables
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local function prototypes
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Global functions
 *---------------------------------------------------------------------*/
/*-----------------------------------------------------------------------
 * read data as two nibbles, fix any PCB track swaps and combine to form a byte
 *---------------------------------------------------------------------*/
unsigned char get_mbus_data(void)
{
//	unsigned char low_swaps[]= {0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f};
//	unsigned char high_swaps[] = {0x00,0x10,0x20,0x30,0x40,0x50,0x60,0x70,0x80,0x90,0xa0,0xb0,0xc0,0xd0,0xe0,0xf0};
	unsigned char low_swaps[]= {0,1,4,5,32,33,36,37,16,17,20,21,48,49,52,53};
	unsigned char high_swaps[] = {0,2,8,10,128,130,136,138,64,66,72,74,192,194,200,202};
	unsigned char low_index, high_index;
	unsigned char low_nibble, high_nibble;


	select_low_nibble();  // repeating gives delay before use
	select_low_nibble();
	select_low_nibble();
	select_low_nibble();
	select_low_nibble();
	low_index   = (inportb(lpt_status_port)^DATA_IN_INVERSIONS) >> 4;
	low_nibble  = low_swaps[low_index];

	select_high_nibble();  // repeating gives delay before use
	select_high_nibble();
	select_high_nibble();
	select_high_nibble();
	select_high_nibble();
	high_index  = (inportb(lpt_status_port)^DATA_IN_INVERSIONS) >> 4;
	high_nibble = high_swaps[high_index];

	return(high_nibble+low_nibble);
}


/*-----------------------------------------------------------------------
 * initialise the pc and interface hardware
 *---------------------------------------------------------------------*/
void initialise_hardware(void)
{
	clear_latch_bit(MB5);
	set_latch_bit(ST);
	set_latch_bit(DI);
	set_latch_bit(IT);
	set_latch_bit(MRESET);
	set_latch_bit(BS0);
	set_latch_bit(BS3);
	delay(1);
}

/*-----------------------------------------------------------------------
 * End of file
 *---------------------------------------------------------------------*/


