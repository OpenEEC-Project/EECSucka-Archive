/*-----------------------------------------------------------------------
 * File:
 * 		j3sim.c
 * Purpose:
 * 		Control software for EEC-IV J3 port simulator
 * Author:
 * 		Andrew March - amarch@icenet.com.au
 * Revisions:
 * 		29 Jun 1999 - v1.00 created from EECSucka v3.00
 * Notes:
 *---------------------------------------------------------------------*/
#ifndef _J3SIM_C
#define _J3SIM_C
#endif

/*-----------------------------------------------------------------------
 * Includes
 *---------------------------------------------------------------------*/
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dos.h>
#include <time.h>
#include "j3sim.h"
#include "io.h"
#include "test.h"


/*-----------------------------------------------------------------------
 * Global variables
 *---------------------------------------------------------------------*/
unsigned int lpt_data_port   = 0x378;
unsigned int lpt_status_port = 0x379;
unsigned int lpt_control_port= 0x37a;


/*-----------------------------------------------------------------------
 * Local constants
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local variables
 *---------------------------------------------------------------------*/

/* set up defaults for parsing of command line options */
unsigned int port_number = 1;
unsigned long rom_size = 56*1024L;
unsigned long rom_offset = 8*1024L;
char file_name[20] = "j3_rom.bin";
int dump_required = TRUE;
int using_menu = TRUE;
int show_usage = FALSE;


/*-----------------------------------------------------------------------
 * Local function prototypes
 *---------------------------------------------------------------------*/
int parse_command_line(int argc, char *argv[]);
int init_printer_port(void);
void display_usage(void);
int menu_mode(void);
int batch_mode(void);
void display_main_menu(void);
void get_file_name(void);

void initialise_EEC(void);
int verify_ROM(void);
int dump_ROM(void);
int show_ROM(void);
void display_hex_data (unsigned char * array, unsigned long len, unsigned long offset);


/*-----------------------------------------------------------------------
 * Main program
 *---------------------------------------------------------------------*/
main(int argc, char *argv[])
{
	int result;


	if ( parse_command_line(argc, &argv[0]) != 0 )
	{
		exit(1);
	}

	if ( init_printer_port() != 0 )
	{
		exit(1);
	}
	else
	{
		// if printer port found we can init pc and interface hardware
		initialise_hardware();
	}

	if (show_usage == TRUE)
	{
		display_usage();
		exit(0);
	}
	else if (using_menu == TRUE)
	{
		menu_mode();
		exit(0);
	}
	else
	{
		result = batch_mode();
		exit(result);
	}

	return(0); // suppresses warning
}


/*-----------------------------------------------------------------------
 * Extract command line options
 * Print error messages to stderr
 * Change defaults according to the command line options
 *---------------------------------------------------------------------*/
int parse_command_line(int argc, char *argv[])
{
	int i;
	int kilobytes;
	int port;
	int result;


	i = 0;
	result = 0;

	while ( (++i < argc) && (result == 0) )
	{
		if ( (*argv[i] == '-') || (*argv[i] == '/') )
		{
			switch (argv[i][1])
			{
				case 'b':
				case 'B':
					using_menu = FALSE;
					break;

				case 'f':
				case 'F':
					strcpy(file_name, argv[++i]);
					break;

				case 'v':
				case 'V':
					// verify only?
					dump_required = FALSE;
					break;

				case 's':
				case 'S':
					if ( sscanf(argv[++i], "%d", &kilobytes) != 1 )
					{
						fprintf(stderr,"\nJ3Sim: Bad number format for -s option\n");
						result = 1;
					}
					else if ( (kilobytes < 1) || (kilobytes > 512) )
					{
						fprintf(stderr,"\nJ3Sim: Bad number range for -s option\n");
						result = 1;
					}
					else
					{
						rom_size = kilobytes*1024L;
					}
					break;

				case 'o':
				case 'O':
					if ( sscanf(argv[++i], "%d", &kilobytes) != 1 )
					{
						fprintf(stderr,"\nJ3Sim: Bad number format for -o option\n");
						result = 1;
					}
					else if ( (kilobytes < 0) || (kilobytes > 511) )
					{
						fprintf(stderr,"\nJ3Sim: Bad number range for -o option\n");
						result = 1;
					}
					else
					{
						rom_offset = kilobytes*1024L;
					}
					break;

				case 'p':
				case 'P':
					if ( sscanf(argv[++i], "%d", &port) != 1 )
					{
						fprintf(stderr,"J3Sim: Bad number format for -p option\n");
						result = 1;
					}
					else if ( (port < 1) || (port > 4) )
					{
						fprintf(stderr,"J3Sim: Bad number range for -p option\n");
						result = 1;
					}
					else
					{
						port_number = port;
					}
					break;

				case 'h':
				case 'H':
					show_usage = TRUE;
					break;

				default:
					fprintf(stderr,"J3Sim: Unknown option -%c\n", argv[i][1]);
					result = 1;
					break;
			}
		}
		else
		{
			fprintf(stderr,"J3Sim: Unexpected character %c\n", *argv[i]);
			result = 1;
		}
	}

	return(result);
}


/*-----------------------------------------------------------------------
 * Print usage guide to screen
 *---------------------------------------------------------------------*/
void display_usage(void)
{
	clrscr();
	printf("\n");
	printf("          J3Sim v1.00 EEC-IV J3 port simulator (C) Andrew J March 1999 \n");
	printf("          ------------------------------------------------------------ \n");
	printf("Help screen:  j3sim -h\n");
	printf("Menu mode:    j3sim [-f file.ext] [-s 1..512] [-o 0..511] [-p 1..4]\n");
	printf("Command line: j3sim -b [-f file.ext] [-v] [-s 1..512] [-o 0..511] [-p 1..4]\n");
	printf("\n");
	printf("  -h   Display these usage notes\n");
	printf("\n");
	printf("  -b   Batch mode\n");
	printf("         Default = menu mode\n");
	printf("\n");
	printf("  -f   File name to dump/verify J3 adaptor ROM (8.3 format)\n");
	printf("         Default = j3_rom.bin\n");
	printf("\n");
	printf("  -v   Verify ROM without dumping\n");
	printf("         Default = Dump and verify ROM\n");
	printf("\n");
	printf("  -s   Size of ROM in kB (kB = 1024 bytes)\n");
	printf("         Default = 56kB\n");
	printf("\n");
	printf("  -o   Offset from start of ROM in kB (kB = 1024 bytes)\n");
	printf("         Default = 8kB\n");
	printf("\n");
	printf("  -p   Specify parallel port 1, 2, 3 or 4\n");
	printf("         Default = LPT1\n");
}


/*-----------------------------------------------------------------------
 * Perform command line options in batch mode
 *---------------------------------------------------------------------*/
int batch_mode(void)
{
	int result;


	// we're either dumping+verifying or verfying
	if ( dump_required == TRUE)
	{
		dump_ROM();
	}

	// always verify
	if ( verify_ROM() != 0 )
	{
		result = 1;
	}
	else
	{
		result = 0;
	}

	return(result);
}


/*-----------------------------------------------------------------------
 * Check whether a port exists for the requested port number
 * if port exists, set up port addresses
 *
 * BIOS lookup table at 0000:0408 returns port address or 0 if no port
 *---------------------------------------------------------------------*/
int init_printer_port(void)
{
	unsigned int lpt_base;
	int result;


	// lookup port base address for requested port number from the BIOS table
	lpt_base = *((unsigned int far *)(0x00000408L)+(port_number-1));

	if (lpt_base == 0)
	{
		fprintf(stderr, "J3Sim: No port found for LPT%d \n", port_number);
		result = 1;
	}
	else
	{
		fprintf(stderr, "J3Sim: Using LPT%d at %Xh\n", port_number, lpt_base);
		lpt_data_port   = lpt_base;
		lpt_status_port = lpt_base + 1;
		lpt_control_port= lpt_base + 2;
		result = 0;
	}

	return(result);
}


/*-----------------------------------------------------------------------
 * User control via menu
 *---------------------------------------------------------------------*/
int menu_mode(void)
{
	int c;


	initialise_hardware();

	do
	{
		clrscr();
		display_main_menu();
		c = toupper(getch());

		switch (c)
		{
			case 'D':
				// dump ROM contents to binary file
				clrscr();
				get_file_name();
				dump_ROM();
				verify_ROM();
				press_any_key();
				break;

			case 'S':
				// show ROM contents on screen
				clrscr();
				show_ROM();
				break;

			case 'V':
				// verify ROM against binary file
				clrscr();
				get_file_name();
				verify_ROM();
				press_any_key();
				break;

			case 'T':
				// test menu
				clrscr();
				select_test();
				break;

			case 'Q':
				// Quit
				break;

			default:
				printf("Invalid option!");
				press_any_key();
				break;
		}
	}
	while (c!='Q');

	clrscr();

	return(0);
}


/*-----------------------------------------------------------------------
 * wait for user to press a key
 *---------------------------------------------------------------------*/
int press_any_key( void)
{
	printf("\nPress any key to continue... ");
	return(getch());
}


/*-----------------------------------------------------------------------
 * Local functions
 *---------------------------------------------------------------------*/

/*-----------------------------------------------------------------------
 * Display main menu
 *---------------------------------------------------------------------*/
void display_main_menu( void)
{
	clrscr();
	printf("\n\n\n");
	printf("                         J3Sim v1.00 Main Menu                     \n");
	printf("                         ---------------------                     \n");
	printf("\n");
	printf("                      D. Dump J3 adaptor ROM to binary file\n");
	printf("                      S. Show J3 adaptor ROM on screen\n");
	printf("                      V. Verify J3 adaptor ROM against binary file\n");
	printf("                      T. Test menu                                 \n");
	printf("                      Q. Quit                                      \n");
	printf("\n");
	printf("                         Select: \n\n\n");
}


/*-----------------------------------------------------------------------
 * prompt user to enter file name
 *---------------------------------------------------------------------*/
void get_file_name(void)
{
	char input_line[100];
	char new_file_name[100];
	int i;

	printf("Enter filename [%s]: ", file_name);

	// overwrite default file name with non-empty input line
	gets(input_line);
	if (sscanf(input_line, "%s", new_file_name)==1)
	{
		strcpy(file_name, new_file_name);
	}

#if 0
	// diagnostic to allow inspection of the final file name
	printf("\n");
	for (i=0; i<12; i++)
	{
		printf("%02X ", file_name[i]);
	}
	printf("\n");
	for (i=0; i<12; i++)
	{
		printf("%3c", file_name[i]);
	}
	printf("\n");
#endif
}


/*-----------------------------------------------------------------------
 * initialise simulated J3 port for dumping adaptor ROM
 *
 *---------------------------------------------------------------------*/
void initialise_J3(void)
{
	load_SPC_address(rom_offset);
	load_DAR_address(rom_offset);
}

/*-----------------------------------------------------------------------
 * dump ROM contents to binary file
 *---------------------------------------------------------------------*/
int dump_ROM(void)
{
	FILE *disk_file;
	unsigned long rom_address;
	unsigned char rom_data;
	int progress_count;


	if ((disk_file = fopen(file_name, "wb")) == NULL)
	{
		printf("Unable to open file %s - check disk\n", file_name);
		return(1);
	}

	printf("Resetting J3 adaptor...");
	initialise_J3();
	printf("OK!\n");

	progress_count = 0;
	for (rom_address = rom_offset; rom_address<(rom_size+rom_offset); rom_address++)
	{
		// display progress every 0x100 bytes
		if (progress_count==0x0100)
		{
			printf("\rSaving ROM location 0x%05lX...", rom_address);
			progress_count = 0;
		}

		// save ROM data at current address to file
		rom_data = get_SPC_byte_inc();
		fputc(rom_data, disk_file);
		progress_count++;
	}

	fclose(disk_file);
	printf("\rSaving ROM location 0x%05lX... %6ld bytes OK!\n", rom_address-1, (rom_address-rom_offset) );
	return(0);
}


/*-----------------------------------------------------------------------
 * verify ROM contents against binary file
 *---------------------------------------------------------------------*/
int verify_ROM(void)
{
	FILE *disk_file;
	unsigned long rom_address;
	unsigned char rom_data;
	int file_data;
	int mismatch;
	int progress_count;
	int result;


	if ((disk_file = fopen(file_name, "rb")) == NULL)
	{
		if (using_menu == TRUE)
		{
			printf("Unable to open file %s - check disk\n", file_name);
			return(1);
		}
		else
		{
			fprintf(stderr, "J3Sim: Unable to open file %s - check disk\n", file_name);
			return(1);
		}
	}

	// get first byte
	if ((file_data = fgetc(disk_file))==EOF)
	{
		printf("Empty file!!!\n");
		fclose(disk_file);
		return(1);
	}

	printf("Resetting J3 adaptor...");
	initialise_J3();
	printf("OK!\n");

	rom_address = rom_offset;
	progress_count = 0;
	mismatch = FALSE;

	while( (file_data!=EOF) && (rom_address < (rom_size+rom_offset)) && (mismatch==FALSE) )
	{
		// display progress every 0x100 bytes
		if (progress_count==0x100)
		{
			printf("\rVerifying ROM location 0x%05lX...", rom_address);
			progress_count = 0;
		}

		// read ROM data and compare against file data
		rom_data = get_SPC_byte();
		if (rom_data!=file_data)
		{
			mismatch = TRUE;
		}
		else
		{
			// get next byte
			file_data = fgetc(disk_file);
			rom_address++;
			progress_count++;
			// increment SPC address
			get_SPC_byte_inc();
		}
	}

	if (mismatch==TRUE)
	{
		printf("\rVerifying ROM location 0x%05lX... failed!!! Expected 0x%02X, read 0x%02X.\n", rom_address, file_data, rom_data);

		if (using_menu == FALSE)
		{
			fprintf(stderr, "J3Sim: Bad verify at ROM location 0x%05lX. Expected 0x%02X, read 0x%02X.\n", rom_address, file_data, rom_data);
		}

		result = 1;
	}
	else
	{
		printf("\rVerifying ROM location 0x%05lX... %6ld bytes OK!\n", rom_address-1, (rom_address-rom_offset) );
		result = 0;
	}

	fclose( disk_file);

	return(result);
}


/*-----------------------------------------------------------------------
 * show ROM contents on the screen
 *---------------------------------------------------------------------*/
int show_ROM(void)
{
	unsigned long rom_address;
	unsigned char rom_data[0x800];
	int block_size;
	int byte_count;
	int quit;


	printf("Resetting J3 adaptor...");
	initialise_J3();
//	printf("OK!\n");

	rom_address = rom_offset;
	block_size = 0x100;
	quit = FALSE;

	do
	{
		byte_count = 0;

		while ( (byte_count < block_size) && (rom_address < (rom_size+rom_offset) ) )
		{
			rom_data[byte_count] = get_SPC_byte();
//			rom_data[byte_count] = byte_count;
			rom_address++;
			byte_count++;
			// increment SPC address
			get_SPC_byte_inc();
		}

		clrscr();
		display_hex_data(&rom_data[0], byte_count, rom_address-block_size);
		printf("\nPress Q to quit or any other key to continue");

		if ( toupper(getch())=='Q' )
		{
			quit = TRUE;
		}

	} while (!quit);

	return(0);
}


/*-----------------------------------------------------------------------
 * Display memory array in format:
 * addr data (hexadecimal)								  data (ascii)
 * 27F: 30 31 32 33 34 35 36 37 30 31 32 33 34 35 36 37  0123456701234567
 *---------------------------------------------------------------------*/
void display_hex_data
	(
	unsigned char * array,				// pointer to bytes to display
	unsigned long len,      			// number of bytes to display
	unsigned long offset    			// displayed address of first byte
	)

{
	int item;							// index into array
	int cnt;                			// number of bytes so far displayed
	int line_cnt;           			// number of lines displayed in current block
	unsigned char c;


	item = 0;
	while (item<len)
	{
		// display address
		printf("0x%05lX: ", offset+item);

		// display up to 16 data bytes
		cnt = 0;
		while ( (cnt<16) && ((item+cnt) < len) )
		{
			printf("%02X ", array[item+cnt]);
			cnt++;
		}

		// pad with spaces up to start of ASCII column
		while (cnt<16)
		{
			printf("   ");
			cnt++;
		}
		printf(" ");

		// display up to 16 ascii chars. if non-printing code, show '.'
		cnt = 0;
		while ( (cnt<16) && ((item+cnt) < len) )
		{
			c = array[item+cnt];
			if ( (c>=0x20) && (c<=0x7f) )
			{
				printf("%c", c);
			}
			else
			{
				printf(".");
			}
			cnt++;
		}

		item += cnt;				// mark off number of bytes displayed
		printf("\n");               // and start a new line
	}
}


/*-----------------------------------------------------------------------
 * End of file
 *---------------------------------------------------------------------*/


