/*-----------------------------------------------------------------------
 * File:
 *      io.h
 * Purpose:
 *      I/O header file for EEC-IV J3 port simulator
 * Author:
 *      Andrew March - amarch@icenet.com.au
 * Notes:
 *---------------------------------------------------------------------*/

/*-----------------------------------------------------------------------
 * Includes
 *---------------------------------------------------------------------*/

/*-----------------------------------------------------------------------
 * Global constants
 *---------------------------------------------------------------------*/

// printer register inversions
#define DATA_IN_INVERSIONS      0x80
#define CONTROL_INVERSIONS      0x0b

// printer port data outputs standard naming
#define PIN_2_D0                0x01
#define PIN_3_D1                0x02
#define PIN_4_D2                0x04
#define PIN_5_D3                0x08
#define PIN_6_D4                0x10
#define PIN_7_D5                0x20
#define PIN_8_D6                0x40
#define PIN_9_D7                0x80

// printer port data outputs eecsucka notation
#define PD0                     PIN_2_D0
#define PD1                     PIN_3_D1
#define PD2                     PIN_4_D2
#define PD3                     PIN_5_D3
#define PD4                     PIN_6_D4
#define PD5                     PIN_7_D5
#define PD6                     PIN_8_D6
#define PD7                     PIN_9_D7

// printer port control outputs standard naming
#define PIN_1_STROBE			0x01
#define PIN_14_AUTO_FEED		0x02
#define PIN_16_INIT			 	0x04
#define PIN_17_SELECT_INPUT	 	0x08

// J3 output signals
#define DI                  	PIN_16_INIT
#define IT                  	PIN_14_AUTO_FEED
#define ST                   	PIN_1_STROBE

// input mux nibble select
#define HI_NIBBLE				PIN_17_SELECT_INPUT


/*-----------------------------------------------------------------------
 * Global variables
 *---------------------------------------------------------------------*/
#ifndef _IO_C
extern unsigned char data_shadow;       // data output register shadow
extern unsigned char control_shadow;    // control output register shadow

#endif /* _IO_C */

/*-----------------------------------------------------------------------
 * Global function prototypes
 *---------------------------------------------------------------------*/
void initialise_hardware(void);
unsigned char get_mbus_data(void);
void load_DAR_address(unsigned int address);
void load_SPC_address(unsigned int address);
unsigned int get_DAR_word(void);
unsigned char get_DAR_byte(void);
unsigned char get_SPC_byte(void);
unsigned char get_SPC_byte_inc(void);


/*-----------------------------------------------------------------------
 * Global inlining
 *---------------------------------------------------------------------*/
/*-----------------------------------------------------------------------
 * write a data byte to the parallel port data output register
 *---------------------------------------------------------------------*/
#define output_port_data(data_value)                                    \
{                                                                       \
	data_shadow = data_value;                                           \
	outportb(lpt_data_port, data_shadow);                               \
}

/*-----------------------------------------------------------------------
 * write a control byte to the parallel port control output register
 * top nibble is cleared to keep data lines as outputs in case of ECP/EPP
 * the control byte is copied to a shadow variable to allow bit set/clear
 * note that any inversions due to PC or application hardware are defined
 * by CONTROL_INVERSIONS and they are handled here
 *---------------------------------------------------------------------*/
#define output_port_control(control_value)                              \
{                                                                       \
	control_shadow = (control_value) & 0x0f;                            \
	outportb(lpt_control_port, control_shadow^CONTROL_INVERSIONS);      \
}

/*-----------------------------------------------------------------------
 * assert/remove controls
 *---------------------------------------------------------------------*/
#define set_DI()           	 output_port_control(control_shadow | DI)
#define clear_DI()         	 output_port_control(control_shadow & ~DI)
#define set_IT()           	 output_port_control(control_shadow | IT)
#define clear_IT()         	 output_port_control(control_shadow & ~IT)
#define set_ST()           	 output_port_control(control_shadow | ST)
#define clear_ST()         	 output_port_control(control_shadow & ~ST)

#define select_low_nibble()                                             \
{                                                                       \
	output_port_control(control_shadow & ~HI_NIBBLE)                    \
	output_port_control(control_shadow & ~HI_NIBBLE)                    \
	output_port_control(control_shadow & ~HI_NIBBLE)                    \
	output_port_control(control_shadow & ~HI_NIBBLE)                    \
	output_port_control(control_shadow & ~HI_NIBBLE)                    \
	output_port_control(control_shadow & ~HI_NIBBLE)                    \
}

#define select_high_nibble()                                            \
{                                                                       \
	output_port_control(control_shadow | HI_NIBBLE)                     \
	output_port_control(control_shadow | HI_NIBBLE)                     \
	output_port_control(control_shadow | HI_NIBBLE)                     \
	output_port_control(control_shadow | HI_NIBBLE)                     \
	output_port_control(control_shadow | HI_NIBBLE)                     \
	output_port_control(control_shadow | HI_NIBBLE)                     \
}

/*-----------------------------------------------------------------------
 * strobe ST output
 *---------------------------------------------------------------------*/
#define strobe_ST()                                                     \
{                                                                       \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	set_ST();                                                           \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	clear_ST();                                                         \
	set_ST();                                                           \
}

/*-----------------------------------------------------------------------
 * interrupt control
 *---------------------------------------------------------------------*/
#define enable_interrupts()     enable()
#define disable_interrupts()    disable()

/*-----------------------------------------------------------------------
 * End of file
 *---------------------------------------------------------------------*/
