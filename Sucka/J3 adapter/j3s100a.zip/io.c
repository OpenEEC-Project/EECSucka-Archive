/*----------------------------------------------------------------------
 * File:
 *		io.c
 * Author:
 * 		Andrew March - amarch@icenet.com.au
 * Purpose:
 * 		I/O low level routines for EEC-IV J3 port simulator
 * Notes:
 ----------------------------------------------------------------------*/
#ifndef _IO_C
#define _IO_C
#endif

/*-----------------------------------------------------------------------
 * Includes
 *---------------------------------------------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dos.h>
#include <time.h>
#include "j3sim.h"
#include "io.h"


/*-----------------------------------------------------------------------
 * Global variables
 *---------------------------------------------------------------------*/
unsigned char data_shadow;  		  	// data output register shadow
unsigned char control_shadow;  		  	// control output register shadow


/*-----------------------------------------------------------------------
 * Local constants
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local variables
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local function prototypes
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Global functions
 *---------------------------------------------------------------------*/
/*-----------------------------------------------------------------------
 * initialise the pc and interface hardware
 *---------------------------------------------------------------------*/
void initialise_hardware(void)
{
	unsigned char i;


	delay(1);
	output_port_data(0xff);
	set_DI();
	set_IT();
	set_ST();
	delay(1);
}

/*-----------------------------------------------------------------------
 * read data as two nibbles, fix any PCB track swaps and combine to form a byte
 *---------------------------------------------------------------------*/
unsigned char get_mbus_data(void)
{
	unsigned char low_swaps[]  = { 0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f};
	unsigned char high_swaps[] = { 0x00,0x10,0x20,0x30,0x40,0x50,0x60,0x70,0x80,0x90,0xa0,0xb0,0xc0,0xd0,0xe0,0xf0};
	unsigned char low_index, high_index;
	unsigned char low_nibble, high_nibble;


	output_port_data(0xff); // make MBUS outputs act as pullups

	select_low_nibble();
	low_index   = (inportb(lpt_status_port)^DATA_IN_INVERSIONS) >> 4;
	low_nibble  = low_swaps[low_index];

	select_high_nibble();
	high_index  = (inportb(lpt_status_port)^DATA_IN_INVERSIONS) >> 4;
	high_nibble = high_swaps[high_index];

	return(high_nibble+low_nibble);
}

/*-----------------------------------------------------------------------
 * load DAR with 16 bit address
 *---------------------------------------------------------------------*/
void load_DAR_address(unsigned int address)
{
	clear_DI();   							// DI=0 J3SIM controls MBUS
	clear_IT();     						// IT=0 selects SPC
	output_port_data(address&0x00ff);   	// place low addr byte on MBUS
	strobe_ST();                        	// latch low addr byte into DAR
	output_port_data((address>>8)&0x00ff);  // place hi addr byte onto MBUS
	strobe_ST();                            // latch low addr byte into DAR
}


/*-----------------------------------------------------------------------
 * load SPC with 16 bit address
 *---------------------------------------------------------------------*/
void load_SPC_address(unsigned int address)
{
	clear_DI();   							// DI=0 J3SIM controls MBUS
	set_IT();     							// IT=1 selects SPC
	output_port_data(address&0x00ff);   	// place low addr byte on MBUS
	strobe_ST();                        	// latch low addr byte into SPC
	output_port_data((address>>8)&0x00ff);  // place hi addr byte onto MBUS
	strobe_ST();                            // latch low addr byte into SPC
}


/*-----------------------------------------------------------------------
 * get data byte using DAR address
 *---------------------------------------------------------------------*/
unsigned char get_DAR_byte(void)
{
	unsigned char data_byte;

	set_DI();   							// DI=1 memory controls MBUS
	clear_IT();    							// IT=0 selects DAR
	data_byte = get_mbus_data();
	return(data_byte);
}


/*-----------------------------------------------------------------------
 * get data word using DAR address
 * on exit DAR contains address it contained on entry incremented by one
 *---------------------------------------------------------------------*/
unsigned int get_DAR_word(void)
{
	unsigned char low_data_byte;
	unsigned char high_data_byte;

	set_DI();   							// DI=1 memory controls MBUS
	clear_IT();    							// IT=0 selects DAR
	low_data_byte = get_mbus_data();
	strobe_ST();                        	// advance to next byte
	high_data_byte = get_mbus_data();
	return((high_data_byte<<8)+low_data_byte);
}

/*-----------------------------------------------------------------------
 * get data byte using SPC address and leave SPC unchanged
  *---------------------------------------------------------------------*/
unsigned char get_SPC_byte(void)
{
	unsigned char data_byte;

	set_DI();   							// DI=1 memory controls MBUS
	set_IT();    							// IT=1 selects SPC
	data_byte = get_mbus_data();            // get data at current SPC addr
	return(data_byte);
}

/*-----------------------------------------------------------------------
 * get data byte using SPC address and post increment SPC
 * on exit SPC contains address it contained on entry incremented by one
 *---------------------------------------------------------------------*/
unsigned char get_SPC_byte_inc(void)
{
	unsigned char data_byte;

	set_DI();   							// DI=1 memory controls MBUS
	set_IT();    							// IT=1 selects SPC
	data_byte = get_mbus_data();            // get data at current SPC addr
	strobe_ST();                        	// increment SPC addr
	return(data_byte);
}



/*-----------------------------------------------------------------------
 * End of file
 *---------------------------------------------------------------------*/
