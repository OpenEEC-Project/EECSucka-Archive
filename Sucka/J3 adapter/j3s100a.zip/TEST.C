/*----------------------------------------------------------------------
 * File:
 *		test.c
 * Purpose:
 * 		test functions for EEC-IV J3 port simulator
 * Author:
 * 		Andrew March - amarch@icenet.com.au
 * Notes:
 ----------------------------------------------------------------------*/
#ifndef _TEST_C
#define _TEST_C
#endif

/*-----------------------------------------------------------------------
 * Includes
 *---------------------------------------------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dos.h>
#include <time.h>
#include "j3sim.h"
#include "io.h"


/*-----------------------------------------------------------------------
 * Global variables
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local constants
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local variables
 *---------------------------------------------------------------------*/


/*-----------------------------------------------------------------------
 * Local function prototypes
 *---------------------------------------------------------------------*/
void display_test_menu(void);
void test_parallel_port(void);
void test_mbus_read(void);
void test_toggle_DI(void);
void test_toggle_IT(void);
void test_toggle_ST(void);
void test_strobe_ST(void);
void test_DAR_marching(void);
void test_SPC_counting(void);
void test_SPC_marching(void);


/*-----------------------------------------------------------------------
 * Global functions
 *---------------------------------------------------------------------*/

/*-----------------------------------------------------------------------
 * Select a test function
 *---------------------------------------------------------------------*/
void select_test(void)
{
	int c;


	do
	{
		initialise_hardware();
		display_test_menu();
		c = toupper(getch());
		switch (c)
			{
		case 'A':
			test_parallel_port();
			break;
		case 'D':
			test_toggle_DI();
			break;
		case 'I':
			test_toggle_IT();
			break;
		case 'S':
			test_toggle_ST();
			break;
		case 'P':
			test_strobe_ST();
			break;
		case 'M':
			test_mbus_read();
			break;
		case 'R':
			test_DAR_marching();
			break;
		case 'C':
			test_SPC_marching();
			break;
		case 'B':
			test_SPC_counting();
			break;
		case 'Q':
			break;
		default:
			printf("Invalid option!");
			press_any_key();
			break;
			}
	}
	while (c!='Q');
}


/*-----------------------------------------------------------------------
 * Local functions
 *---------------------------------------------------------------------*/

/*-----------------------------------------------------------------------
 * display test menu
 *---------------------------------------------------------------------*/
void display_test_menu( void)
{
	clrscr();
	printf("\n\n\n");
	printf("                         Test Menu                    \n");
	printf("                         ---------                    \n");
	printf("\n");
	printf("                      A. Parallel port                \n");
	printf("                      D. Toggle DI                    \n");
	printf("                      I. Toggle IT                    \n");
	printf("                      S. Toggle ST                    \n");
	printf("                      P. Strobe ST                    \n");
	printf("                      M. Input data mux (MB0:7)       \n");
	printf("                      R. DAR address marching 1's     \n");
	printf("                      C. SPC address marching 1's     \n");
	printf("                      B. SPC address binary count     \n");
	printf("                      Q. Return to main menu          \n");
	printf("\n");
	printf("                         Select: \n\n\n");
}


/*-----------------------------------------------------------------------
 * test operation of parallel port
 * on user key-press set data lines then control lines high one at a time
 * while displaying state of the input lines
 *---------------------------------------------------------------------*/
void test_parallel_port(void)
{
	unsigned char status;
	int	c;
	int index = 0;
	int pattern[] = {
					0x100, 0x001, 0x002, 0x004, // STROBE- DO D1 D2
					0x008, 0x010, 0x020, 0x040, // D3 D4 D5 D6
					0x080, 0x200, 0x400, 0x800  // D7 AUTOF- INIT- SEL.IN-					} ;
					} ;


	initialise_hardware();

	do
	{
		status = inportb(lpt_status_port) ^ DATA_IN_INVERSIONS;
		outportb(lpt_data_port, pattern[index] & 0xff);
		outportb(lpt_control_port, (pattern[index] >> 8) ^ CONTROL_INVERSIONS);

		clrscr();
		printf("    Parallel port test    \n");
		printf("--------------------------\n");
		printf("Outputs are in UPPER CASE \n");
		printf("--------------------------\n");
		printf(" 1  STROBE-    (N/C)  ");
		if (index == 0)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 2  DATA 0     (PD0)  ");
		if ( index == 1)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 3. DATA 1     (PD1)  ");
		if (index == 2)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 4. DATA 2     (PD2)  ");
		if (index == 3)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 5. DATA 3     (PD3)  ");
		if (index == 4)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 6. DATA 4     (PD4)  ");
		if (index == 5)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 7. DATA 5     (PD5)  ");
		if (index == 6)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 8. DATA 6     (PD6)  ");
		if (index == 7)
			printf("1<-\n");
		else
			printf("0\n");

		printf(" 9. DATA 7     (PD7)  ");
		if (index == 8)
			printf("1<-\n");
		else
			printf("0\n");

		printf("10. ack-       (PN2)  %d\n", (status & 0x40) ? 1: 0);
		printf("11. busy       (PN3)  %d\n", (status & 0x80) ? 1: 0);
		printf("12. paper end  (PN1)  %d\n", (status & 0x20) ? 1: 0);
		printf("13. select     (PN0)  %d\n", (status & 0x10) ? 1: 0);

		printf("14. AUTO FEED- (N/C)  ");
		if ( index == 9)
			printf("1<-\n");
		else
			printf("0\n");

		printf("15. error-     (N/C)  %d\n", (status & 0x08) ? 1: 0);

		printf("16. INIT-      (PC0)  ");
		if (index == 10)
			printf("1<-\n");
		else
			printf("0\n");

		printf("17. SEL INPUT- (PC1)  ");
		if (index == 11)
			printf("1<-\n");
		else
			printf("0\n");

		printf("--------------------------\n");

		index = (index+1) % 12;

		printf("\nPress any key or Q to quit\n");
		c = toupper(getch());
	}
	while(c!='Q');
	initialise_hardware();
}


/*-----------------------------------------------------------------------
 * test operation of input data multiplexer
 * on user key-press display data byte present on MB[7:0]
 *---------------------------------------------------------------------*/
void test_mbus_read(void)
{
	unsigned char b;
	int	c;


	initialise_hardware();

	do
	{
		clrscr();
		b = get_mbus_data();
		printf("Data input mux test\n");
		printf("-------------------\n");
		printf("Data read = 0x%02X\n", b);
		printf("\nPress any key or Q to quit\n");
		c = toupper(getch());
	}
	while(c!='Q');

	initialise_hardware();
}


/*-----------------------------------------------------------------------
 * toggle DI outout
 *---------------------------------------------------------------------*/
void test_toggle_DI(void)
{
	unsigned char c;
	int state;

	initialise_hardware();

	state = 0; // assume pin is low to toggle into high state initially

	do
	{
		clrscr();
		printf("Toggle DI output\n");
		printf("----------------\n");

		if (state==0)
		{
			set_DI();
			state = 1;
			printf("DI output is high\n");
		}
		else
		{
			clear_DI();
			state = 0;
			printf("DI output is low\n");
		}

		printf("\nPress any key or Q to quit\n");

		c = toupper(getch());
	}
	while(c!='Q');

	initialise_hardware();
}

/*-----------------------------------------------------------------------
 * toggle IT outout
 *---------------------------------------------------------------------*/
void test_toggle_IT(void)
{
	unsigned char c;
	int state;

	initialise_hardware();

	state = 0; // assume pin is low to toggle into high state initially

	do
	{
		clrscr();
		printf("Toggle IT output\n");
		printf("----------------\n");

		if (state==0)
		{
			set_IT();
			state = 1;
			printf("IT output is high\n");
		}
		else
		{
			clear_IT();
			state = 0;
			printf("IT output is low\n");
		}

		printf("\nPress any key or Q to quit\n");

		c = toupper(getch());
	}
	while(c!='Q');

	initialise_hardware();
}

/*-----------------------------------------------------------------------
 * toggle ST outout
 *---------------------------------------------------------------------*/
void test_toggle_ST(void)
{
	unsigned char c;
	int state;

	initialise_hardware();

	state = 0; // assume pin is low to toggle into high state initially

	do
	{
		clrscr();
		printf("Toggle ST output\n");
		printf("----------------\n");

		if (state==0)
		{
			set_ST();
			state = 1;
			printf("ST output is high\n");
		}
		else
		{
			clear_ST();
			state = 0;
			printf("ST output is low\n");
		}

		printf("\nPress any key or Q to quit\n");

		c = toupper(getch());
	}
	while(c!='Q');

	initialise_hardware();
}

/*-----------------------------------------------------------------------
 * pulse ST outout repetitively
 *---------------------------------------------------------------------*/
void test_strobe_ST(void)
{
	int	c;

	initialise_hardware();
	set_ST();

	clrscr();
	printf("Strobe ST output\n");
	printf("----------------\n");
	printf("\nPress any key to quit\n");

	do
	{
#if 0
		strobe_ST();
		delay(1);
#else
		set_ST();
		delay(1);
		clear_ST();
		delay(1);
#endif
	}
	while(!kbhit());
	c = toupper(getch());

	initialise_hardware();
}

/*-----------------------------------------------------------------------
 * set address lines A0 to A15 high in turn one at a time using DAR
 *---------------------------------------------------------------------*/
void test_DAR_marching(void)
{
	unsigned int address;
	int	bit;
	int c;


	initialise_hardware();

	bit = 0;
	address = 0x0001;
	load_DAR_address(address);
	set_DI(); // give control of MBUS to memory to enable OE

	do
	{
		clrscr();
		printf("DAR address output test (marching 1's)\n");
		printf("--------------------------------------\n");
		printf("A%-2d set, current address=0x%04X\n",bit,address);

		printf("\nPress any key or Q to quit\n");

		c = toupper(getch());
		if (c!='Q')
		{
			// increment bit number and form address
			bit = (bit+1) % 16;
			if (bit==0)
			{
				address = 0x0001;
			}
			else
			{
				address <<= 1;
			}

			// load new address into DAR
			load_DAR_address(address);
			set_DI(); // give control of MBUS to memory to enable OE
		}
	}
	while(c!='Q');

	initialise_hardware();
}

/*-----------------------------------------------------------------------
 * set address lines A0 to A15 high in turn one at a time using SPC
 *---------------------------------------------------------------------*/
void test_SPC_marching(void)
{
	unsigned int address;
	unsigned int SPC_shadow_address;
	int	bit;
	int c;


	initialise_hardware();

	bit = 0;
	address = 0x0001;
	SPC_shadow_address = 0x0001;
	load_SPC_address(address);
	set_DI(); // give control of MBUS to memory to enable OE

	do
	{
		clrscr();
		printf("SPC address output test (marching 1's)\n");
		printf("--------------------------------------\n");
		printf("A%-2d set, current address=0x%04X\n",bit,address);

		printf("\nPress any key or Q to quit\n");

		c = toupper(getch());
		if (c!='Q')
		{
			// increment bit number and form new address
			bit = (bit+1) % 16;
			if (bit==0)
			{
				address = 0x0001;
			}
			else
			{
				address <<= 1;
			}

			// increment SPC until it matches required address
			while (SPC_shadow_address != address)
			{
				get_SPC_byte_inc();
				SPC_shadow_address++;
			}

			set_DI(); // give control of MBUS to memory to enable OE
		}
	}
	while(c!='Q');

	initialise_hardware();
}

/*-----------------------------------------------------------------------
 * place binary count on address lines A0 to A15 using SPC
 *---------------------------------------------------------------------*/
void test_SPC_counting(void)
{
	unsigned int address;
	int c;


	initialise_hardware();

	address = 0x0000;
	load_SPC_address(address);
	set_DI(); // give control of MBUS to memory to enable OE

	do
	{
		clrscr();
		printf("SPC address output test (binary count)\n");
		printf("--------------------------------------\n");
		printf("Current address=0x%04X\n",address);

		printf("\nPress any key to increment count or Q to quit\n");

		c = toupper(getch());
		if (c!='Q')
		{
			// increment SPC address
			get_SPC_byte_inc();
			address++;
			set_DI(); // give control of MBUS to memory to enable OE
		}
	}
	while(c!='Q');

	initialise_hardware();
}

/*-----------------------------------------------------------------------
 * End of file
 *---------------------------------------------------------------------*/


